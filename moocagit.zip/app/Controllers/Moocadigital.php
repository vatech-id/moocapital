<?php

namespace App\Controllers;
use App\Controllers\BaseController;

class Moocadigital extends BaseController
{
    public function index()
    {
        $data = [
            'judul' => 'Portofolio Mooca Digital | '
        ];
        echo view('header', $data);
        echo view('digital_detail');
        echo view('footer');
    }
}

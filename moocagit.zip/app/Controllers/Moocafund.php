<?php

namespace App\Controllers;
use App\Controllers\BaseController;

class Moocafund extends BaseController
{
    public function index()
    {
        $data = [
            'judul' => 'Portofolio Mooca Fund | '
        ];
        echo view('header', $data);
        echo view('fund_detail');
        echo view('footer');
    }
}

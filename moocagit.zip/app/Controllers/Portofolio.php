<?php

namespace App\Controllers;
use App\Controllers\BaseController;

class Portofolio extends BaseController
{
    public function index()
    {
        $data = [
            'judul' => 'Portofolio | '
        ];
        echo view('header', $data);
        echo view('portofolio');
        echo view('footer');
    }
}

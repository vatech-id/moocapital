<?php

namespace App\Controllers;
use App\Controllers\BaseController;

class Subsidiary extends BaseController
{
    public function index()
    {
        $data = [
            'judul' => 'Portofolio Mooca Subsidiary | '
        ];
        echo view('header', $data);
        echo view('subsidiary_detail');
        echo view('footer');
    }
}

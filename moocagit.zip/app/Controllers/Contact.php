<?php

namespace App\Controllers;
use App\Controllers\BaseController;

class Contact extends BaseController
{
    public function index()
    {
        $data = [
            'judul' => 'Contact | '
        ];
        echo view('header', $data);
        echo view('contact');
        echo view('footer');
    }

    public function kirim()
    {
        $nama = $this->request->getVar('name');
        $email_user = $this->request->getvar('email');
        $subject = $this->request->getvar('subject');
        $message = $this->request->getVar('message');

        return redirect('https://api.whatsapp.com/send?phone=6285655662660');
    }
}

<?php

namespace App\Controllers;
use App\Controllers\BaseController;

class Home extends BaseController
{
    public function index()
    {
        $data = [
            'judul' => 'Home | '
        ];
        echo view('header', $data);
        echo view('home');
        echo view('footer');
    }
}

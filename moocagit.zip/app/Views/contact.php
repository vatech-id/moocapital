  <main class="main">

    <!-- Contact Section -->
    <section id="contact" class="contact section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Contact</h2>
        <p>Please contact us if there is a need. Thank You</p>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4">

          <div class="col-lg-5">

            <div class="info-wrap">
              <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="200">
                <i class="bi bi-geo-alt flex-shrink-0"></i>
                <div>
                  <h3>Address</h3>
                  <p>Vallenca Office, Blitar ID </p>
                </div>
              </div><!-- End Info Item -->

              <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="300">
                <i class="bi bi-telephone flex-shrink-0"></i>
                <div>
                  <h3>Call Us</h3>
                  <p>085655662660</p>
                </div>
              </div><!-- End Info Item -->

              <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
                <i class="bi bi-envelope flex-shrink-0"></i>
                <div>
                  <h3>Email Us</h3>
                  <p><a href="mailto:admin@moocapital.biz.id">admin@moocapital.biz.id</a></p>
                </div>
              </div><!-- End Info Item -->
            </div>
      </div>

        <div class="col-lg-7">
          <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15795.125934467362!2d112.3014817!3d-8.2247168!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e78be5885a51fc9%3A0xf621ded896ecafd7!2sCV.%20VALLENCA%20CORPORA!5e0!3m2!1sid!2sid!4v1725756876806!5m2!1sid!2sid" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div><!-- End Contact Form -->

    </section><!-- /Contact Section -->

  </main>
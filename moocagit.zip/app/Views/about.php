<main class="main">

    <!-- About Section -->
    <section id="about" class="about section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>About</h2>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4 justify-content-center">
          <div class="col-lg-4">
            <img src="assets/img/profile-img.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-8 content">
            <h2>Mooca Capital Company</h2>
            <p class="fst-italic py-3">
              Mooca Capital Company is a group of companies founded by a small family in the Java Islands. Mooca itself is another name for the type of mocha coffee favored by the founder of this business group. We strive to create a friendly and sustainable business and prioritize technological developments
            </p>
            <p>
              Our business group consists of:
            </p>
            <div class="row">
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>E-commerce and its ecosystem</strong> </li>
                  <li><i class="bi bi-chevron-right"></i> <strong>IT & Technology services</strong> </li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Media and education</strong></li>
                </ul>
              </div>
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Investment</strong></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Asset management</strong></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Business development in potential sectors</strong> </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>

    </section><!-- /About Section -->

  </main>
